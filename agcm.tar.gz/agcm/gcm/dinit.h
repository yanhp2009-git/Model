

      COMMON /DSCOM/ DRAG,DRAGG(KX)



     
      
      
      

      
      
      
