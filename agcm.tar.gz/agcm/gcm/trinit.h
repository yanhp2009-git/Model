

      COMMON /TRCOM/  TREQ(IL,KX),TRTAU0



     
      
      
      

      
      
      
