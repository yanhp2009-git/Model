

      COMMON /RCOM/ RADEQ(IL,KX),RTAU(IL,KX),RTAU1,
     * TSURF(IL),DELV(IL),TSTRAT(IL),
     * ALFSG(KX)



     
      
      
      

      
      
      
