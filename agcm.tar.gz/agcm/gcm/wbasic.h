c this common block saves the information for a standard atmos.
c which is used to set alf surfaces
c----- xwang 06/28/1999
c
       COMMON/basicair/zstr(IX,IL),PSG0(IX,IL),PSX(IX,IL),PSY(IX,IL)
     *     ,PSMB(IX,IL),XH11(MX,NX),DSIGB(KX),Tsb0,ps00,RTRD,TTI
