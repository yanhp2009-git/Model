

#ifdef t127
      PARAMETER ( NTRUN=127, MTRUN=127, IX=384, IY=96 )   
#endif

#ifdef t63
      PARAMETER ( NTRUN=63, MTRUN=63, IX=192, IY=48 )   
#endif

#ifdef t42
      PARAMETER ( NTRUN=42, MTRUN=42, IX=128, IY=32 )   
#endif

#ifdef t30
      PARAMETER ( NTRUN=30, MTRUN=30, IX=96, IY=24 )   
#endif

#ifdef t21
      PARAMETER ( NTRUN=21, MTRUN=21, IX=64, IY=16 )   
#endif

#ifdef r30
      PARAMETER ( NTRUN=30, MTRUN=30, IX=96, IY=40 )   
#endif

#ifdef r15
      PARAMETER ( NTRUN=15, MTRUN=15, IX=48, IY=20 )   
#endif

#ifdef pr30
      PARAMETER ( NTRUN=30, MTRUN=30, IX=64, IY=32 )    
#endif

#ifdef pr15
      PARAMETER ( NTRUN=15, MTRUN=15, IX=32, IY=16 )    
#endif

#ifdef pt30
      PARAMETER ( NTRUN=30, MTRUN=30, IX=64, IY=16 )   
#endif

#ifdef pt63
      PARAMETER ( NTRUN=63, MTRUN=63, IX=128, IY=32 )   
#endif

      PARAMETER (ISC=1)

      PARAMETER (NX=NTRUN+2, MX=MTRUN+1 , MXNX=MX*NX,MX2=2*MX)
      PARAMETER (IL=2*IY, NTRUN1=NTRUN+1 )
      PARAMETER (NXP=NX+1 , MXP=ISC*MTRUN+1 )
      PARAMETER (NWAVES=1+IX/2)
      PARAMETER (NX2=NX*2)
      PARAMETER (IYM=IY-1)
      PARAMETER (MXNX2=2*MX*NX)
      PARAMETER (LMAX=MXP+NX-2)
      PARAMETER (IX2=2*IX)
