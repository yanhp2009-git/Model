
      COMMON/KCOM/XA(KX,KX),XB(KX,KX),XC(KX,KX),
     * XD(KX,KX),XE(KX,KX),XF(KX,KX,LMAX),XG(KX,KX,LMAX),
     * XH(KX,KX,LMAX),XJ(KX,KX,LMAX),TREF1(KX),DHSX(KX),
     * ELZ(MX,NX)




     
      
      
      

      
      
      
