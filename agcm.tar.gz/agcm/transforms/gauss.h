
      COMMON /GAUSS/ SIA(IY),COA(IY),WT(IY),WGHT(IY),
     *     COSG(IL),COSGR(IL),cosgr2(il)
